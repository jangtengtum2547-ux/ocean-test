# OCEAN Big Five Personality Test

เว็บไซต์แบบประเมินบุคลิกภาพเพื่อการสำรวจตนเองที่อิงกรอบ Big Five / OCEAN

## ไฟล์
- `index.html` — โครงสร้างหน้าเว็บ
- `style.css` — ดีไซน์ responsive / mobile-first
- `app.js` — คำถาม, validation, scoring, interpretation, localStorage

## วิธีเปิดใช้งาน
ไม่ต้องติดตั้ง Node.js หรือ backend:
1. ดาวน์โหลดไฟล์ทั้งหมดไว้ในโฟลเดอร์เดียวกัน
2. เปิด `index.html` ด้วยเบราว์เซอร์
3. หากต้องการทดสอบผ่าน local server สามารถใช้ VS Code Live Server หรือ `python -m http.server`

## Logic
แต่ละด้านมี 6 ข้อ คะแนนต่อข้อ 1–5:
- Raw score: 6–30
- Normalized score: `((rawScore - 6) / 24) * 100`
- 0–39 = ค่อนข้างต่ำ
- 40–59 = ระดับกลาง
- 60–100 = ค่อนข้างสูง

รองรับ `reverseScored` ใน data structure แล้ว แม้คำถามรุ่นนี้จะยังเป็น false ทั้งหมด

## Validation
มีการตรวจ:
- 30 คำถาม
- Trait ละ 6 ข้อ
- Trait ต้องเป็น O/C/E/A/N
- คำตอบต้องเป็น integer 1–5
- ตอบครบก่อนคำนวณ
- raw score 6–30
- normalized score 0–100
- NaN / Infinity / null / undefined
- คะแนนสูงสุด/ต่ำสุดกรณีเสมอ
- ป้องกัน submit ซ้ำ
- localStorage สำหรับคำตอบชั่วคราว
- error details อยู่ใน Developer Console

## Developer test cases
สามารถทดสอบใน UI ได้ด้วย:
1. ตอบครบ → ต้องเห็นผลลัพธ์
2. ข้าม 1 ข้อ → ไม่ให้ส่ง และชี้ข้อที่ขาด
3. ข้ามหลายข้อ → แจ้งจำนวนข้อ
4. ป้อนค่าไม่ถูกต้องผ่าน DevTools → scoring ต้อง reject
5. ทุกข้อ = 1 → ทุกด้าน 0/100
6. ทุกข้อ = 5 → ทุกด้าน 100/100
7. ทำให้ O และ C เท่ากัน → แสดงแนวโน้มเด่นร่วม
8. Refresh ระหว่างทำ → คำตอบคงอยู่จาก localStorage
9. กด Submit รัว ๆ → ไม่สร้างผลลัพธ์ซ้ำ
10. ทดสอบหน้าจอมือถือ → ปุ่มและตัวเลือกต้องไม่ล้น

## หมายเหตุ
แบบประเมินนี้ไม่ใช่แบบทดสอบทางคลินิก ไม่ได้อ้างว่าได้รับการรับรองหรือ psychometric validation และไม่ใช้เพื่อวินิจฉัยหรือแนะนำการลงทุน
